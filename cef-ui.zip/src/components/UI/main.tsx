import { Transition, Flex, Card, Stack, Title, Group, useMantineTheme } from "@mantine/core";
import { useCefEvent } from '../../hooks/useNuiEvent'; // ganti dari useNuiEvent
import useAppVisibilityStore from '../../stores/appVisibilityStore';

export function UI() {
  const theme = useMantineTheme();
  const { showApp, setVisibility } = useAppVisibilityStore();


  // Menerima event dari CEF / pawn
  useCefEvent<boolean>("UPDATE_VISIBILITY", (data) => {
    setVisibility(data);
  });

  const fetchData = () => {
    (window as any).cef.emit("FETCH_DATA", ""); // Ganti dengan event yang sesuai
  }

  return (
    <Transition mounted={showApp} transition="fade" duration={400} timingFunction="ease">
      {(transStyles) => (
        <Flex
          pos="fixed"
          w="100vw"
          h="100vh"
          style={{
            pointerEvents: "none",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Card
            p="xl"
            style={{
              ...transStyles,
              backgroundColor: theme.colors.dark[8],
              borderRadius: theme.radius.md,
              maxWidth: "500px",
              width: "100%",
              pointerEvents: "auto",
            }}
          >
            <Stack align="center" gap="xs">
              <Group gap="xs">
                <Title c="white">DISTRICT ROLEPLAY</Title>
              </Group>

              <Button
                variant="light"
                color="blue"
                onClick={fetchData()}
                style={{ width: "100%" }}
              >
                Close
              </Button>              
            </Stack>
          </Card>
        </Flex>
      )}
    </Transition>
  );
}
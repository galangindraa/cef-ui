// src/comp/identity/CreateKrakterFormInner.tsx
import { Controller, useFormContext } from "react-hook-form";
import { TextInput, Fieldset } from "@mantine/core";
import { createKrakterFormSchemaType } from "./forms";

export const CreateKrakterFormInner = () => {
  const { control, formState: { errors } } = useFormContext<createKrakterFormSchemaType>();

  return (
    <Fieldset variant="unstyled" radius="xl">
      <div className="space-y-4">
        <Controller
          name="firtstname"
          control={control}
          render={({ field }) => (
            <TextInput
              {...field}
              label="First Name"
              placeholder="Enter first name"
              error={errors.firtstname?.message}
            />
          )}
        />
        <Controller
          name="lastname"
          control={control}
          render={({ field }) => (
            <TextInput
              {...field}
              label="Last Name"
              placeholder="Enter last name"
              error={errors.lastname?.message}
            />
          )}
        />
      </div>
    </Fieldset>
  );
};
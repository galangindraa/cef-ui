import { z } from "zod";

export const createKrakterFormSchema = z.object({
  firtstname: z
    .string()
    .min(3, { message: "Username minimal 3 karakter" })
    .max(16, { message: "Username maksimal 16 karakter" }),
    lastname: z
    .string()
    .min(3, { message: "Username minimal 3 karakter" })
    .max(16, { message: "Username maksimal 16 karakter" }),
});

export type createKrakterFormSchemaType = z.infer<typeof createKrakterFormSchema>;